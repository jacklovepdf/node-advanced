const app = getApp()

Page({
  data: {

  },
  onLoad: function () {
    console.log('头条小程序代码片段，可点击以下链接查看代码片段的详细文档')
  },
  bindDetect:function(){
    wx.navigateTo({
      url:'/pages/detect/detect'
    })
  },
  bindSearch:function(){
    wx.navigateTo({
      url:'/pages/detect2/detect2'
    })
  },

})
