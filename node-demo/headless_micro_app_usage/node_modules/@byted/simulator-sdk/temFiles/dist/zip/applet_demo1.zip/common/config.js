
const urlRegex = str => /^((http|https):\/\/)?[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?$/.test(str);

function _login() {
    wx.login({
        success: (res) => {
            console.log('login: success');
            const { code } = res;
            wx.request({
                url: 'https://m.toutiao.com/detector/api/login/?code=' + code,
                success: (res) => {
                    const openid = res.data.data;
                    wx.setStorageSync('openid', openid);
                },
            });
        },
        fail: (res) => {
            console.log('login: fail');
        },
    });
}

function login() {
    wx.checkSession({
        success: () => {
            console.log('check session: success');
            const openid = wx.getStorageSync('openid');
            const user = wx.getStorageSync('user');
            if (!openid || !user) {
                _login();
            }
        },
        fail: () => {
            console.log('check session: fail');
            _login();
        },
    });
}

function storeSearch(search) {
    let history = wx.getStorageSync('detect_history')
    console.log('history'+history)
    console.log('search '+search+' is going to be stored')
    if(!history){
        history = []
        let time = new Date().getTime()
        history.push({
            time:time,
            search:search
        })
        wx.setStorageSync('detect_history',JSON.stringify(history))
    }else{
        history = JSON.parse(history)
        let time = new Date().getTime()
        history=history.filter(h=>h.search!=search)
        history.push({
            time:time,
            search:search
        })
        history.sort((a,b)=>a.time<=b.time)
        history = history.slice(0,5)
        wx.setStorageSync('detect_history',JSON.stringify(history))
    }
}

function getSearch(){
    let history = wx.getStorageSync('detect_history')
    if (!history){
        return []
    }
    history = JSON.parse(history)
    return history
}



function savePicToAlbum(tempFilePath) {
    const that = this;
    wx.getSetting({
        success(res) {
            if (!res.authSetting['scope.writePhotosAlbum']) {
                wx.authorize({
                    scope: 'scope.writePhotosAlbum',
                    success() {
                        wx.saveImageToPhotosAlbum({
                            filePath: tempFilePath,
                            success(res) {
                                wx.showToast({
                                    title: '保存成功',
                                });
                            },
                            fail(res) {
                                console.log(res);
                            },
                        });
                    },
                    fail() {
                        // 用户拒绝授权,打开设置页面
                        wx.openSetting({
                            success: function (data) {
                                console.log('openSetting: success');
                            },
                            fail: function (data) {
                                console.log('openSetting: fail');
                            },
                        });
                    },
                });
            } else {
                wx.saveImageToPhotosAlbum({
                    filePath: tempFilePath,
                    success(res) {
                        wx.showToast({
                            title: '保存成功',
                        });
                    },
                    fail(res) {
                        console.log(res);
                    },
                });
            }
        },
        fail(res) {
            console.log(res);
        },
    });
}

const isIPhoneX = (() => {
    const systemInfo = wx.getSystemInfoSync();
    return systemInfo.model.indexOf('iPhone X') > -1;
})();

const RESULT_RUMOUR_1 = 0
const RESULT_RUMOUR_2 = 1
const RESULT_HOT = 2
const RESULT_SENSITIVE = 3
const RESULT_NORMAL = 4
const RESULT_ERROR = 5

const ENV = 'dev'
const baseUrl = ENV==='dev'?'https://nlp.bytedance.net/lingquan-antirumour/api':''


module.exports = {
    urlRegex: urlRegex,
    savePicToAlbum: savePicToAlbum,
    login: login,
    isIPhoneX,
    RESULT_RUMOUR_1,
    RESULT_RUMOUR_2,
    RESULT_HOT,
    RESULT_SENSITIVE,
    RESULT_ERROR,
    RESULT_NORMAL,
    storeSearch,
    getSearch,
    baseUrl
};

