import { test } from '../util';

worker.onMessage((e) => {
  // throw new Error('worker error test');
  console.log('main said:', e);
  worker.postMessage({ ...e, _ext: test() });
  console.log("1112222")
})
