// pages/music/index.js
import { errMsg } from '../../common/constants';
import { getFileName } from '../../common/utils';
Page({
  data: {
    imgDes: '选择一张能表达你心情的照片,我们将会推荐你最适合的背景音乐。',
    btnDes: '上传照片',
    imgPath: '/common/images/music_bg.png'
  },
  onLoad: function (options) {

  },
  chooseImage: function() {
    var that = this;
    tt.chooseImage({
      sourceType: ['camera'],
      sizeType: 'compressed',
      count: 1,
      success (res) {
        let imgUrl = res.tempFilePaths[0];
            
        that.setData({
          imgPath: imgUrl
        });
        wx.saveFile({
          tempFilePath: imgUrl,
          success(res) {
            const savedFilePath = res.savedFilePath
            console.log("saveFile res:", res);
            let imgData = FileSystemManager.readFileSync(savedFilePath, 'base64'),
                extName = getFileName(savedFilePath),
                imgBase = `data:image/${extName};base64,${imgData};`; 
             
            
          }
        })
      },
      fail (res) {
        tt.showToast({
          title: errMsg.chooseImage,
        });
      }
    })
  }
})