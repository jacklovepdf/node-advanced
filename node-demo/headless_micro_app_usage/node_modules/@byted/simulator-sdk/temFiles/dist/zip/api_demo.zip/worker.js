worker.onMessage((e) => {
  console.log('main said:', e);
  worker.postMessage(e);
})