import { test } from '../util';
worker.onMessage((e) => {
  console.log('main said:', e);
  worker.postMessage({ ...e, _ext: test() });
})
