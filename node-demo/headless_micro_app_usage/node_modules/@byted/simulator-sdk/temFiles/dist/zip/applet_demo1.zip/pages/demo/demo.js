const app = getApp()
const { RESULT_RUMOUR_1, RESULT_RUMOUR_2, RESULT_HOT, RESULT_SENSITIVE, RESULT_ERROR, RESULT_NORMAL, storeSearch, getSearch, baseUrl } = require('../../common/config.js');
Page({
   data: {
      canvasHeight: 600,
      title: '水果有雌雄之分?共水果比木水果更好吃吗',
      content: '水果分“公母”没有科学依据，但形状会影响口感，所谓的分辨公母好吃的就是无稽之谈了',
      tip: '灵犬谣言模型检测为谣言事件'
   },
   onLoad(options) {
       debugger
      const context = tt.createCanvasContext('myCanvas'); // 创建绘图上下文
      context.drawImage('/static/image/bg-img.png',10,10)
      // let height = 0
      // let rec_y = height+30
      // let title_y = rec_y+25
      // let screenSize = wx.getSystemInfoSync()
      // //左右各15+15
      // let textWidth = screenSize.windowWidth-60
      // let text = this.data.title
      // this.textWrap({
      //    x:30,
      //    y:title_y,
      //    color:'#222222',
      //    width:textWidth,
      //    height:30,
      //    size:22,
      //    align:'left',
      //    baseline:'top',
      //    text:this.data.title,
      //    bold:true,
      //    line:3
      // },context)
      // //console.log(l)
      context.draw(); //绘图
   },
   writeTextOnCanvas(ctx_2d, lineheight, bytelength, text, startleft, starttop) {
      function getTrueLength(str) {//获取字符串的真实长度（字节长度）  
         var len = str.length, truelen = 0;
         for (var x = 0; x < len; x++) {
            if (str.charCodeAt(x) > 128) {
               truelen += 2;
            } else {
               truelen += 1;
            }
         }
         return truelen;
      }
      function cutString(str, leng) {//按字节长度截取字符串，返回substr截取位置  
         var len = str.length, tlen = len, nlen = 0;
         for (var x = 0; x < len; x++) {
            if (str.charCodeAt(x) > 128) {
               if (nlen + 2 < leng) {
                  nlen += 2;
               } else {
                  tlen = x;
                  break;
               }
            } else {
               if (nlen + 1 < leng) {
                  nlen += 1;
               } else {
                  tlen = x;
                  break;
               }
            }
         }
         return tlen;
      }
      for (var i = 1; getTrueLength(text) > 0; i++) {
         var tl = cutString(text, bytelength);
         ctx_2d.fillText(text.substr(0, tl).replace(/^\s+|\s+$/, ""), startleft, (i - 1) * lineheight + starttop);
         text = text.substr(tl);
      }
   },

   textWrap(obj,ctx) {
      console.log('niceboy')
      console.log('文本换行')
      var td = Math.ceil(obj.width / (obj.size));
      var tr = Math.ceil(obj.text.length / td);
      for (var i = 0; i < tr; i++) {
         var txt = {
            x: obj.x,
            y: obj.y + (i * obj.height),
            color: obj.color,
            size: obj.size,
            align: obj.align,
            baseline: obj.baseline,
            text: obj.text.substring(i * td, (i + 1) * td),
            bold: obj.bold
         };
         if (i < obj.line) {
            if (i == obj.line - 1) {
               txt.text = txt.text.substring(0, txt.text.length - 3) + '......';
            }
            this.drawText(txt,ctx);
         }else{
            return i*obj.height
         }
      }
   },
   drawText: function (obj,ctx) {
      console.log('渲染文字')
      ctx.save();
      ctx.setFillStyle(obj.color);
      ctx.setFontSize(obj.size);
      ctx.setTextAlign(obj.align);
      ctx.setTextBaseline(obj.baseline);
      if (obj.bold) {
          console.log('字体加粗')
          ctx.fillText(obj.text, obj.x, obj.y - 0.5);
          ctx.fillText(obj.text, obj.x - 0.5, obj.y);
      }
      ctx.fillText(obj.text, obj.x, obj.y);
      if (obj.bold) {
          ctx.fillText(obj.text, obj.x, obj.y + 0.5);
          ctx.fillText(obj.text, obj.x + 0.5, obj.y);
      }
      ctx.restore();
  }
})
