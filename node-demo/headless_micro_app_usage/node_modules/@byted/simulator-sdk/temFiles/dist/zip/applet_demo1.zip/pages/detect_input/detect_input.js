const app = getApp()
const { RESULT_RUMOUR_1, RESULT_RUMOUR_2, RESULT_HOT, RESULT_SENSITIVE, RESULT_ERROR, RESULT_NORMAL, storeSearch, getSearch, baseUrl } = require('../../common/config.js');
Page({
    data: {
        hot_searches: [
            '水果有雌雄之分吗?',
            '千吨病死猪肉最近流入市场?',
            '网警辟谣：网传"美国纽约皇后区发生爆炸"系谣言aaaaaaa',
            '同一个地方会不会出现两次闪电?'
        ],
        change_lock: false,
        value: '',
        suggest_items: []
    },
    onLoad(options) {
        let words = options.words
        this.setData({
            value:words
        })
        this.loadSuggest(this.data.value)
    },
    onReady() {
    },

    bindInput: function (e) {
        const value = e.detail.value
        this.setData({
            value: value
        });
        this.loadSuggest(value)
    },
    bindConfirm: function (e) {
        let searched = this.data.value.trim()
        let userid = 'applet_user'

        let timeout = false
        if (searched) {
            let _timer=setTimeout(() => {
                wx.hideLoading()
                wx.showToast({
                  title: '网络超时',
                  icon:'',
                  duration:2000
                })
                this.lock = false
                timeout = true
              }, 10e3)
            storeSearch(searched)
            let url = baseUrl+"/rumour_detect"
            wx.request({
                url: url,
                method: 'post',
                data: {
                  keyword: searched,
                  user_id: userid
                },
                header: {
                  'content-type': 'application/json'
                },
                success: (res) => {
                  if(timeout || this.hidden){
                    return 
                  }
                  clearTimeout(_timer)
                  wx.hideLoading()
                  this.lock = false
                  const data = res.data
                  let errorNavigator = function(result_code){
                    wx.navigateTo({
                      url:`/pages/error/error?result_code=${result_code}`
                    })
                  }
                  if(data.code===RESULT_ERROR){
                    wx.showToast({
                      icon:'',
                      title:"服务器出现了一点小问题，请稍后重试~",
                      duration:2000
                    })
                    errorNavigator(RESULT_ERROR)
                  }
                  else if(data.code===RESULT_SENSITIVE){
                    wx.showToast({
                      icon:'',
                      title:'该内容需要人工审核',
                      duration:2000
                    })
                    errorNavigator(RESULT_SENSITIVE)
                  }
                  else if(data.code===RESULT_HOT){
                    wx.showToast({
                      icon:'',
                      title:'你命中了热搜，真棒!',
                      duration:2000
                    })
                  }
                  else if(data.code===RESULT_NORMAL){
                    console.log('go to detect result')
                    let detect_title = ''
                    let detect_deny_rumour = '未查询到辟谣库内容'
                    if(data.score<0.2){
                        wx.navigateTo({
                          url:`/pages/trace/trace?detect_words=${searched}`
                        })
                        return
                      }
                    var date = new Date()
                    let o  = {
                      //detect_message:data.message,
                      detect_score:data.score,
                      detect_title:data.rumour,
                      detect_words:searched,
                      detect_deny_rumour:data.rumour_detail,
                      detect_time:date.toLocaleString()
                    }
                    o = JSON.stringify(o)
                    wx.setStorageSync('detect_result',o)
                    wx.navigateTo({
                      url:`/pages/detect_result/detect_result`
                    })
          
                  }
                  else if(data.code<0){
                    console.log('Error code:'+data.code)
                    let msg = ":"+data.message
                    if(!msg){
                      msg = ""
                    }
                    wx.showToast({
                      icon:'none',
                      title:'检测异常'+msg,
                      duration:2000
                    })
                    errorNavigator(data.code)
                  }
                },
                fail: (res) => {
                    console.log(res)
                    if(timeout||this.hidden){
                      return
                    }
                    clearTimeout(_timer)
                    wx.hideLoading()
                    this.lock = false
                    wx.navigateTo({
                      url:'/pages/error/error'
                    })
                }
              })
            //todo search this
        } else {
            wx.showToast({
                title: '内容过短,请重新输入!',
                icon: 'none',
                duration: 1500
            })
        }
    },
    loadSuggest(value) {
        let input = value.trim()
        if (input) {//如果输入值有意义，请求推荐搜索
            let userid='applet_user'
            let url = baseUrl+'/suggest'
            wx.request({
                url: url,
                method: 'post',
                data: {
                  sentence: input,
                  userid: userid
                },
                header: {
                  'content-type': 'application/json'
                },
                success:(r)=>{
                    const data = r.data
                    console.log(data)
                    this.setData({
                        suggest_items:data.result
                    })
                },
                fail:(e)=>{
                    console.log(e)
                }
                    
            })

        } else {//否则，查询本地历史搜索
            let searched = getSearch()
            console.log(searched)
            let suggests = searched.map(s => {
                let data = {
                    from: 'history',
                    text: s.search
                }
                return data
            })
            this.setData({
                suggest_items: suggests
            })
        }
    }
    ,
    searchHot(e) {
        let hot_words = e.currentTarget.dataset.hot
        let w = ''
        hot_words.forEach(e=>{
            w = w+e.text
        })
        console.log(w)
        this.setData({
            value:w
        })
        this.loadSuggest(w)
        this.bindConfirm()
    },
    searchHistory(e){
        let s = e.currentTarget.dataset.history
        console.log(s)
        this.setData({
            'value':s
        })
        this.loadSuggest(s)
    },
    clearInput(e){
        this.setData({
            value:''
        })
        this.loadSuggest('')
    },
    goBack(e) {
        wx.navigateBack()
    }
})
