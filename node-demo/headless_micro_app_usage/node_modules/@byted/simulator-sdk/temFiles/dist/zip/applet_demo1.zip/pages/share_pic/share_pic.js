const app = getApp()

const { savePicToAlbum, isIPhoneX } = require('../../common/config')
/*
看起来头条小程序有bug，不支持canvas绘制图片，这样就没法分享保存了
*/
Page({
    data: {
        imagePath: '/image/share.jpg',
        result: {},
        contentHeight: 0
    },
    onLoad(options) {
        let result = JSON.parse(wx.getStorageSync('detect_result'))
        console.log(result)
        this.setData({
            result: result
        })
        var context = wx.createCanvasContext('myCanvas')
        this.init2(context)
    },
    init2(context){
        this.setData({
            contentHeight:200
        })
        context.setFontSize(24)
        context.setTextAlign("left");
        context.setFillStyle("#000000");
        context.drawImage('../static/image/real.png',10,30,100,100)
        
        context.fillText('yes!!!',150,100)
        context.draw()
    }
    ,
    initCanvas(context) {
        let size = this.getCanvasSize()
        console.log(size)
        let title = this.data.result.detect_words
        let content = this.data.result.detect_deny_rumour
        title = this.splitSentence(title, 12)
        content = this.splitSentence(content, 16)
        //height记录内容的长度
        let height = 50
        context.setFontSize(24)
        context.setTextAlign("left");
        context.setFillStyle("#000000");
        title.forEach(ele => {
            context.fillText(ele, size.w * 0.1, height, size.w );
            height = height + 27
        });
        height = height + 18
        context.setFontSize(18)
        context.setTextAlign("left");
        context.setFillStyle("#000000");
        content.forEach(ele => {
            context.fillText(ele, size.w * 0.1, height, size.w )
            height = height + 20
        })

        height = height+22
        let axis = size.w*0.1

        context.drawImage('/static/image/real.png',axis,height,100,100)
        context.setFontSize(14)
        context.setFillStyle('#999999')
        context.fillText('灵犬谣言模型鉴定为谣言事件',axis+20,height+3)

        height = height+18

        this.setData({
            contentHeight: height + 100
        })

        let start_x = size.w*0.05
        this.roundRect(context,size.w*0.05,0,size.w*0.9,height,5)
        context.draw()
    },
    splitSentence(s, limit) {
        let o = []
        let lines = s.split("\n").map(s => s.trim()).filter(s => s.length > 0)
        for (var idx in lines) {
            let line = lines[idx]
            let curLength = line.length
            let count = (curLength - 1) / limit
            for (var i = 0; i <= count; i++) {
                o.push(line.substring(i * limit, (i + 1) * limit))
            }
        }
        return o
    },
    getCanvasSize: function () {
        var size = {};
        try {
            var res = wx.getSystemInfoSync();
            size.w = res.windowWidth;
            size.h = res.windowHeight;
        } catch (e) {
            // Do something when catch error
            console.log("获取设备信息失败" + e);
        }
        return size;
    },
    save() {
        wx.canvasToTempFilePath({
            canvasId: 'myCanvas',
            success: function (res) {
                var tempFilePath = res.tempFilePath;
                console.log(tempFilePath)
            }
        })
    },
    roundRect(ctx, x, y, w, h, r) {
        // 开始绘制
        ctx.beginPath()
        // 因为边缘描边存在锯齿，最好指定使用 transparent 填充
        // 这里是使用 fill 还是 stroke都可以，二选一即可
        ctx.setFillStyle('#E8E8E8')
        // ctx.setStrokeStyle('transparent')
        // 左上角
        ctx.arc(x + r, y + r, r, Math.PI, Math.PI * 1.5)
      
        // border-top
        ctx.moveTo(x + r, y)
        ctx.lineTo(x + w - r, y)
        ctx.lineTo(x + w, y + r)
        // 右上角
        ctx.arc(x + w - r, y + r, r, Math.PI * 1.5, Math.PI * 2)
      
        // border-right
        ctx.lineTo(x + w, y + h - r)
        ctx.lineTo(x + w - r, y + h)
        // 右下角
        ctx.arc(x + w - r, y + h - r, r, 0, Math.PI * 0.5)
      
        // border-bottom
        ctx.lineTo(x + r, y + h)
        ctx.lineTo(x, y + h - r)
        // 左下角
        ctx.arc(x + r, y + h - r, r, Math.PI * 0.5, Math.PI)
      
        // border-left
        ctx.lineTo(x, y + r)
        ctx.lineTo(x + r, y)
      
        // 这里是使用 fill 还是 stroke都可以，二选一即可，但是需要与上面对应
        ctx.stroke()
        // ctx.stroke()
        ctx.closePath()
        // 剪切
        ctx.clip()
      }

})