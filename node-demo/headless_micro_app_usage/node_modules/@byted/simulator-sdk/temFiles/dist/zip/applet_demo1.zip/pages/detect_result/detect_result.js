const app = getApp()

const { savePicToAlbum, isIPhoneX } = require('../../common/config')

Page({
  data: {
    title: '水果有雌雄之分?公水果比木水果更笑死我了好吃吗公水果比木水果更笑死我了好吃吗公水果比木水果更笑死我了好吃吗公水果比木水果更笑死我了好吃吗公水果比木水果更笑死我了好吃吗?',
    content: '水果分“公母”没有科学依据，但形状会影响口感。既然没有“公母水果”，所老弟你怎么回事所老弟你怎么回所所老弟你怎么回所老弟你怎么回老弟你怎么回所老弟你怎么回所老弟你怎么回所老弟你怎么回谓的分辨水果公母选择好吃的水果就是无稽之谈了！',
    tip: '灵犬谣言模型检测为谣言事件',
    result: 'fake',
    maskHidden: true,
    imagePath: "/images/share.jpg",
  },
  savePicture() {
    // console.log('Saving picture')
    // wx.navigateTo({
    //   url:'/pages/share_pic/share_pic'
    // })
    console.log('下载暂并不支持')

  },
  onLoad() {
    let result = JSON.parse(wx.getStorageSync('detect_result'))
    let score = result.detect_score
    let tip
    let rumourType
    if (score <= 0.2) {
      tip = '灵犬谣言模型检测可信度为80%'
      rumourType = 'real'
      wx.redirectTo({
        url:`/pages/trace/trace?detect_words=${result.detect_words}`
      })
    } else if (score < 0.7) {
      tip = '灵犬谣言模型驾车可信度为50%'
      rumourType = 'suspicious'
    } else {
      tip = '灵犬谣言模型检测为谣言事件'
      rumourType = 'fake'
    }
    console.log(result)
    this.setData({
      title: result.detect_title,
      content: result.detect_deny_rumour,
      tip: tip,
      result: rumourType
    })
  },
  onShareAppMessage(options){
    return {
      title:'灵犬邀您一起打击谣言',
      desc:this.data.title,
      path:'/pages/index/index',
      success(){
        console.log('转发中')
      },
      fail(){
        console.log('转发失败')
        wx.showToast({
          title:'Fail',
          duration:2000,
          icon:'none'
        })
      }

    }
  }

})