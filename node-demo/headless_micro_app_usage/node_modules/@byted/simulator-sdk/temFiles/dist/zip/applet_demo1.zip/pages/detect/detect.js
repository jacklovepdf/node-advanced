const app = getApp()
const {RESULT_RUMOUR_1,RESULT_RUMOUR_2,RESULT_HOT,RESULT_SENSITIVE,RESULT_ERROR,RESULT_NORMAL,storeSearch,getSearch} = require('../../common/config.js');
Page({
  data: {
    value: '',
    search_hot:false,
    search_history:false,
    hot_list:[{text:'OK'}],
    history_list:[{
      text:'NO',
      // i love dota
      dota: 'puck'
    },{
      text:'very baddddddsagsdagasdvkmadspovmaewovmawoevmoawmvd',
      dota: 'storm spirit'
    }]
  },
  lock: false,
  onLoad: function () {
    //console.log('头条小程序代码片段，可点击以下链接查看代码片段的详细文档')
  },
  detect: function (e) {
    const userid = 'applet_user'
    let value = this.data.value.trim()
    if (value.length < 10) {
      wx.showToast({
        title: '内容过短,请重新输入!',
        icon: 'none',
        duration: 2000
      })
      this.lock = false
      return
    }
    storeSearch(value)
    console.log('detect value is:'+value)
    wx.showLoading({
      title: '正在检测',
      mask: true
    })
    let timeout = false
    this._timer = setTimeout(() => {
      wx.hideLoading()
      wx.showToast({
        title: '网络超时',
        icon:'',
        duration:2000
      })
      this.lock = false
      timeout = true
    }, 10e3)
    wx.request({
      url: 'http://10.224.6.189:8765/api/rumour_detect',
      method: 'post',
      data: {
        keyword: value,
        user_id: userid
      },
      header: {
        'content-type': 'application/json'
      },
      success: (res) => {
        if(timeout || this.hidden){
          return 
        }
        clearTimeout(this._timer)
        wx.hideLoading()
        this.lock = false
        const data = res.data
        let errorNavigator = function(result_code){
          wx.navigateTo({
            url:`/pages/error/error?result_code=${result_code}`
          })
        }
        if(data.code===RESULT_ERROR){
          wx.showToast({
            icon:'',
            title:"服务器出现了一点小问题，请稍后重试~",
            duration:2000
          })
          errorNavigator(RESULT_ERROR)
        }
        else if(data.code===RESULT_SENSITIVE){
          wx.showToast({
            icon:'',
            title:'该内容需要人工审核',
            duration:2000
          })
          errorNavigator(RESULT_SENSITIVE)
        }
        else if(data.code===RESULT_HOT){
          wx.showToast({
            icon:'',
            title:'你命中了热搜，真棒!',
            duration:2000
          })
        }
        else if(data.code===RESULT_RUMOUR_1||data.code===RESULT_RUMOUR_2||data.code===RESULT_NORMAL){
          console.log('go to detect result')
          let detect_title = ''
          let detect_deny_rumour = '未查询到辟谣库内容'
          if (data.data){
            detect_title = data.data.title
            if(data.data.deny.hit){
              detect_deny_rumour = data.data.deny.doc.content
            }
          }
          var date = new Date()
          let o  = {
            detect_message:data.message,
            detect_score:data.data.score,
            detect_words:data.content,
            detect_title:detect_title,
            detect_deny_rumour:detect_deny_rumour,
            detect_time:date.toLocaleString()
          }
          o = JSON.stringify(o)
          wx.setStorageSync('detect_result',o)
          wx.navigateTo({
            url:`/pages/detect_result/detect_result`
          })

        }
        else if(data.code<0){
          console.log('Error code:'+data.code)
          let msg = ":"+data.message
          if(!msg){
            msg = ""
          }
          wx.showToast({
            icon:'none',
            title:'检测异常'+msg,
            duration:2000
          })
          errorNavigator(data.code)
        }
      },
      fail: (res) => {
          console.log(res)
          if(timeout||this.hidden){
            return
          }
          clearTimeout(this._timer)
          wx.hideLoading()
          this.lock = false
          wx.navigateTo({
            url:'/pages/error/error'
          })
      }
    })
  },
  bindInput: function (e) {
    //console.log('this data is '+e.detail.value)
    this.setData({
      value: e.detail.value,
    });
  },
  clearInput: function (e) {
    this.setData({
      value: '',
    });
  },
  queryHot:function(e){
    console.log('show share')
    tt.showShareMenu({
      success(res){
        console.log('show share success')
      },
      fail(res){
        console.log('show share failed')
      }
    })
    // this.setData({
    //   search_hot:!this.data.search_hot,
    //   search_history:false
    // })
  },
  queryHistory:function(e){
    let searched=getSearch()
    console.log('history search clicked')
    console.log(searched)
    this.setData({
      search_history:!this.data.search_history,
      search_hot:false,
      history_list:searched
    })
  },
  lift_words:function(e){
    let value = e.currentTarget.dataset.search
    console.log('selected value is {}',value)
    this.setData({
      value:value,
      search_history:false,
      search_hot:false
    })
  }
})
