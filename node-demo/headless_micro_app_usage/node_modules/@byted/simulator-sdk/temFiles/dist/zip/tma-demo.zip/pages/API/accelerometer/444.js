// pages/API/accelerometer/444.js
Page({
  data: {

  },
  onLoad: function (options) {

  }
})