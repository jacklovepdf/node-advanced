// pages/API/accelerometer/222.js
Page({
  data: {

  },
  onLoad: function (options) {

  }
})