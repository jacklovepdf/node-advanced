Page({
  data: {
    url: "https://s3.pstatp.com/toutiao/static/img/logo.201f80d.png"
  }
})
