const app = getApp()

Page({
  data: {
    result_code:0
  },
  onLoad: function (options) {
    const {result_code} = options
    this.setData({
      result_code:result_code
    })
  },
  bindDetect:function(){
    wx.navigateTo({
      'url':'/page/detect/detect'
    })
  },
  bindSearch:function(){
    wx.navigateTo({
      'url':'/page/search/search'
    })
  },

})
