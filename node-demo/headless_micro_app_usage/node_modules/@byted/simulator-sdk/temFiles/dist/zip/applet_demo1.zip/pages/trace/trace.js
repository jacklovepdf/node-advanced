const app = getApp()
const {RESULT_RUMOUR_1,RESULT_RUMOUR_2,RESULT_HOT,RESULT_SENSITIVE,RESULT_ERROR,RESULT_NORMAL,storeSearch,getSearch,baseUrl} = require('../../common/config.js');
Page({
    data:{
        detect_words:'OFO谁拥有马化腾口中的一票否决权',
        suggested:[]
    },
    onLoad(options){
        let detect_words = options.detect_words
        let news=this.loadNews(detect_words)
        this.setData({
            detect_words:detect_words,
            suggested:news
        })
    },
    loadNews(words){
        return [{
            title:'OFO谁拥有马化腾口中的一票否决权',
            tip:'人民网 12评论 5分钟前'
        },{
            title:'北京总部ofo退押金，让用户体验了有史以来最长的派对',
            tip:'海外网 30评论 10分钟前'
        },{
            title:'戴威开全员大会:ofo不会倒闭，其它都有可能',
            tip:'央视网新闻 0评论 1分钟前'
        }]
    }
})
