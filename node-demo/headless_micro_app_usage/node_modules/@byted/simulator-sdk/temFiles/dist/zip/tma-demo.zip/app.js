App({
    onLaunch: function () {
        console.log('App Launch')
    },
    onShow: function (res) {
        console.log('App Show', res);
        
    },
    onHide: function (res) {
        console.log('App Hide1111', res);
    } 
});




