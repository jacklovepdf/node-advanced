// pages/API/accelerometer/333.js
Page({
  data: {

  },
  onLoad: function (options) {

  }
})