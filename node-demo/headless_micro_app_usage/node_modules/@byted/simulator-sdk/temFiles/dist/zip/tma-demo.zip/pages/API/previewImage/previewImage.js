// page/API/pages/previewImage/previewImage.js
Page({
  previewPureNetworkImage () {
    tt.previewImage({
      urls: [
        "http://p3.pstatp.com/origin/pgc-image/153112639238924dfe953d1",
        "http://p1.pstatp.com/origin/pgc-image/1531126392813c2431a6822",
        "http://p3.pstatp.com/origin/pgc-image/1531126392970b5fec3f0ae",
        "http://p3.pstatp.com/origin/pgc-image/15311263935789acc10ae8f",
        "http://p3.pstatp.com/origin/pgc-image/1531126393722c8794641f0",
        "http://p1.pstatp.com/origin/pgc-image/15311263939280982f77ea0",
        "http://p1.pstatp.com/origin/pgc-image/15311263943568a3b6f5120",
        "http://p3.pstatp.com/origin/pgc-image/153112639453931f940b1a9",
        "http://p1.pstatp.com/origin/pgc-image/15311263947135a2eba2042",
        "http://p9.pstatp.com/origin/pgc-image/15311263948556362471b22",
        "http://p3.pstatp.com/origin/pgc-image/1531126395091e1f18ec8c9",
        "http://p3.pstatp.com/origin/pgc-image/15311263952547a4143bbfe"
      ],
    })
  },
  /**
   * 页面的初始数据
   */
  data: {
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})