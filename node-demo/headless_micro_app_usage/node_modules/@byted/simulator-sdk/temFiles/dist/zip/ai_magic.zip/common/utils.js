
export function getFileName(url){
    return (url || '').split('.').slice(-1);
}