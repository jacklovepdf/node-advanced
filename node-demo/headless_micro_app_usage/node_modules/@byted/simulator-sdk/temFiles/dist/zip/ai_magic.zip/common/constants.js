export const goods = [
    {
        title: '智能配乐',
        path: '/pages/music/index',
        imgUrl: '/common/images/test.jpg'
    },
    {
        title: '商品智能识别与搜索',
        path: '/pages/music/index',
        imgUrl: '/common/images/test.jpg'
    },
    {
        title: '服饰穿搭推荐',
        path: '/pages/music/index',
        imgUrl: '/common/images/test.jpg'
    },
    {
        title: '扫一扫',
        path: '/pages/music/index',
        imgUrl: '/common/images/test.jpg'
    },
    {
        title: 'P图',
        path: '/pages/music/index',
        imgUrl: '/common/images/test.jpg'
    },
    {
        title: '敬请期待',
        path: '/pages/music/index',
        imgUrl: '/common/images/test.jpg'
    }
]

export const errMsg = {
    chooseImage: '上传图片失败, 请重新选择。'
}

export const api = 'https://lab.bytedance.net/tce/api/';