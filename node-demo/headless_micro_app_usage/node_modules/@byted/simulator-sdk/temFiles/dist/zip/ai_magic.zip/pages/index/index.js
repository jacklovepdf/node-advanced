import { goods } from '../../common/constants';
Page({
  data: {
    goods: goods,
    imgUrl: '/common/images/logo.jpg'
  },
  onShow: function() {
  },
  showCurrentPage: function(ev) {
    const path = ev.currentTarget.dataset.path;
    console.log("ev.currentTarget==>",ev.currentTarget, "path===>",path)
    if(path){
      tt.navigateTo({
        url: path,
        complete:function(){
          console.log("complete navigateto");
        }
      });
    }else{
      console.error('path is not exist!');
    }
  }
})
