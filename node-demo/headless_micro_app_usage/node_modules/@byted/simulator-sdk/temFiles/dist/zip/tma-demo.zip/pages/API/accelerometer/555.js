// pages/API/accelerometer/555.js
Page({
  data: {

  },
  onLoad: function (options) {

  }
})